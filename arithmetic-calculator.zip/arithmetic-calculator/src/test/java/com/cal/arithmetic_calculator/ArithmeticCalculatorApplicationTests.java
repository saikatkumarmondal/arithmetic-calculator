package com.cal.arithmetic_calculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArithmeticCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
